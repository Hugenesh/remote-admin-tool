"""
SafeDesk Remote Assist - shared protocol and utilities.

DESIGN PRINCIPLE (the "legit" part):
    Nothing on a client PC is ever shared until a human on that PC
    explicitly presses Accept for that specific session request.

WIRE FORMAT
    Every message on the TCP socket is framed as:
        [4-byte big-endian payload length][1-byte message type][payload]
    The length field counts ONLY the payload bytes.

    Message types:
        0x01 = JSON control message   (requests, grants, denials, end)
        0x02 = JPEG screen frame      (client -> helper only)

LAN DISCOVERY
    Client answers UDP broadcasts on port 5556 so the helper can list
    nearby "device IDs" instead of typing IP addresses (AnyDesk-style,
    but LAN-scoped).

SESSION LOGS
    Every consent decision, grant, denial, timeout and disconnect is
    appended to logs/<role>_<date>.log next to the scripts.
"""

import json
import os
import random
import socket
import struct
import threading
import time

APP_NAME = "SafeDesk Remote Assist"
APP_VERSION = "1.0"
PROTO_VERSION = 1

TYPE_JSON = 0x01
TYPE_FRAME = 0x02

DEFAULT_TCP_PORT = 5555
PORT_RANGE = 12                    # client tries 5555..5566 if 5555 is taken
DISCOVERY_PORT = 5556
DISCOVERY_PROBE = b"SAFEDESK-DISCOVER-V1"

CONSENT_TIMEOUT = 30               # seconds the approval popup stays open
MAX_PAYLOAD = 25 * 1024 * 1024     # sanity cap on a single frame (25 MB)


# ---------------------------------------------------------------------------
# Framing
# ---------------------------------------------------------------------------

def send_msg(sock, mtype, payload):
    """Send one framed message (type + payload)."""
    sock.sendall(struct.pack("!IB", len(payload), mtype) + payload)


def send_json(sock, obj):
    send_msg(sock, TYPE_JSON, json.dumps(obj).encode("utf-8"))


def _recv_exact(sock, n):
    buf = bytearray()
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            return None            # peer closed cleanly
        buf.extend(chunk)
    return bytes(buf)


def recv_msg(sock):
    """Return (mtype, payload) or None on clean EOF. Raises OSError on resets."""
    header = _recv_exact(sock, 5)
    if header is None:
        return None
    length, mtype = struct.unpack("!IB", header)
    if length > MAX_PAYLOAD:
        raise OSError("payload too large: %d bytes" % length)
    if length == 0:
        return mtype, b""
    payload = _recv_exact(sock, length)
    if payload is None:
        return None
    return mtype, payload


def recv_json(sock):
    msg = recv_msg(sock)
    if msg is None:
        return None
    mtype, payload = msg
    if mtype != TYPE_JSON:
        raise OSError("expected JSON control message, got type 0x%02x" % mtype)
    return json.loads(payload.decode("utf-8"))


# ---------------------------------------------------------------------------
# Audit logging (both sides record every decision)
# ---------------------------------------------------------------------------

class AuditLogger:
    """Thread-safe, append-only audit trail.

    Writes to logs/<role>_<YYYYMMDD>.log and optionally mirrors each line
    into the GUI via a callback. Records consent decisions, grants,
    denials, timeouts and session lifecycle events - useful evidence if
    anyone ever asks "who connected to this machine and when".
    """

    def __init__(self, role, base_dir=None, gui_cb=None):
        self.role = role
        self.gui_cb = gui_cb
        self._lock = threading.Lock()
        base = base_dir or os.path.dirname(os.path.abspath(__file__))
        self.log_dir = os.path.join(base, "logs")
        try:
            os.makedirs(self.log_dir, exist_ok=True)
        except OSError:
            self.log_dir = base
        self.path = os.path.join(
            self.log_dir, "%s_%s.log" % (role, time.strftime("%Y%m%d")))
        self.log("APP_START", app=APP_NAME, version=APP_VERSION, pid=os.getpid())

    def log(self, event, **fields):
        line = "[%s] [%s] %s" % (
            time.strftime("%Y-%m-%d %H:%M:%S"), self.role.upper(), event)
        if fields:
            line += " " + " ".join("%s=%s" % (k, v) for k, v in fields.items())
        with self._lock:
            try:
                with open(self.path, "a", encoding="utf-8") as fh:
                    fh.write(line + "\n")
            except OSError:
                pass
        if self.gui_cb:
            try:
                self.gui_cb(line)
            except Exception:
                pass
        return line


# ---------------------------------------------------------------------------
# Small host/network helpers
# ---------------------------------------------------------------------------

def get_lan_ip():
    """Best-effort primary LAN address. No packet actually leaves the NIC."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
    except OSError:
        ip = "127.0.0.1"
    finally:
        s.close()
    return ip


def host_name():
    try:
        return socket.gethostname() or "unknown-pc"
    except OSError:
        return "unknown-pc"


def new_session_id():
    """Random 9-digit per-session number shown in the approval popup."""
    return str(random.randint(100000000, 999999999))


def make_device_id(role):
    """Stable 9-digit device id, persisted next to the scripts."""
    base = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(base, ".%s_device_id" % role)
    try:
        with open(path, "r", encoding="utf-8") as fh:
            val = fh.read().strip()
        if val.isdigit() and len(val) == 9:
            return val
    except OSError:
        pass
    val = new_session_id()
    try:
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(val)
    except OSError:
        pass
    return val


def format_id(digits):
    """123456789 -> 123 456 789 (AnyDesk-style grouping)."""
    d = str(digits)
    if len(d) == 9:
        return "%s %s %s" % (d[0:3], d[3:6], d[6:9])
    return d


# ---------------------------------------------------------------------------
# LAN discovery: client responder + helper scanner
# ---------------------------------------------------------------------------

def start_discovery_responder(info_cb, logger=None):
    """Client side. Answers UDP probes with this device's announce info.

    info_cb: callable returning a dict with at least
             {"id": ..., "name": ..., "port": <tcp port>}
    """
    def loop():
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind(("", DISCOVERY_PORT))
        except OSError as exc:
            if logger:
                logger.log("DISCOVERY_BIND_FAIL", port=DISCOVERY_PORT, error=str(exc))
            return
        if logger:
            logger.log("DISCOVERY_LISTENING", port=DISCOVERY_PORT)
        while True:
            try:
                data, addr = s.recvfrom(1024)
                if data.strip() != DISCOVERY_PROBE:
                    continue
                reply = dict(info_cb())
                reply["type"] = "announce"
                # Reply straight back to the probe's source address.
                s.sendto(json.dumps(reply).encode("utf-8"), addr)
                if logger:
                    logger.log("DISCOVERY_ANNOUNCED", to=addr[0])
            except OSError:
                continue

    t = threading.Thread(target=loop, daemon=True, name="discovery-responder")
    t.start()
    return t


def scan_lan(timeout=2.5):
    """Helper side. Broadcast a probe and collect announce replies.

    Returns {ip: info_dict} of every SafeDesk client that answered.
    """
    results = {}
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    s.settimeout(0.25)
    targets = ["255.255.255.255"]
    ip = get_lan_ip()
    if ip and ip != "127.0.0.1":
        targets.append(".".join(ip.split(".")[:3]) + ".255")
    for target in targets:
        try:
            s.sendto(DISCOVERY_PROBE, (target, DISCOVERY_PORT))
        except OSError:
            pass
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            data, addr = s.recvfrom(4096)
            info = json.loads(data.decode("utf-8"))
            if info.get("type") == "announce":
                results[addr[0]] = info
        except (OSError, ValueError):
            continue
    s.close()
    return results
