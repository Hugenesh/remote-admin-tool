# SafeDesk Remote Assist

A small, consent-based remote screen-viewing tool for Windows (LAN only),
built in Python with a dark CustomTkinter GUI. It behaves like a
minimal AnyDesk: the helper PC connects, the client PC gets a big popup,
and **nothing is ever shared until a human on the client presses
ACCEPT**.

## IMPORTANT - authorized use only

This tool is for legitimately supporting and monitoring systems you own
or administer (your family PCs, your lab, your company endpoints with
the user's knowledge). The consent popup and the audit log are the core
safety design: the person at the client PC always sees who is asking,
can reject with one click, and every decision is recorded. Do not
remove the consent gate and do not use this on machines you have no
right to touch.

## How the consent gate works (the "legit" part)

1. Client app sits quietly in the system tray-equivalent state:
   "PROTECTED - waiting for requests". It shares nothing, ever, on its own.
2. Helper sends a connection request (their display name + IP + a fresh
   9-digit session ID).
3. The client PC shows a topmost modal popup for 30 seconds:
   - who is asking (name + IP)
   - the session ID to verify out-of-band
   - ACCEPT / REJECT buttons
4. If the user does nothing, the request is AUTO-REJECTED at 0 s.
5. If ACCEPTED, live screen streaming starts (view-only, ~12 fps JPEG).
6. Either side can end instantly: client "END SESSION" banner button,
   helper "Stop viewing", or closing either app.
7. Everything (requests, grants, denials, timeouts, disconnects,
   durations) is written to `logs/client_YYYYMMDD.log` and
   `logs/helper_YYYYMMDD.log`.

## Files

| File                | What it is                                        |
|---------------------|---------------------------------------------------|
| `client.py`         | Run on the PC that will be viewed                 |
| `helper.py`         | Run on the support/defense PC that views          |
| `common.py`         | Shared wire protocol, discovery, audit logger     |
| `install_deps.bat`  | One-click dependency installer                    |
| `start_client.bat`  | One-click client launcher                         |
| `start_helper.bat`  | One-click helper launcher                         |
| `logs/`             | Audit logs are created here automatically         |

## Quick start (Windows)

1. Install Python 3.9+ on **both** PCs (python.org, tick
   "Add python.exe to PATH" during setup).
2. Copy this whole folder to both PCs.
3. On each PC, double-click `install_deps.bat` once.
   It installs: `customtkinter`, `mss`, `pillow`.
4. On the client PC: double-click `start_client.bat`.
   - Windows Firewall may ask -> allow on **Private networks**.
   - The window shows the device ID (e.g. `123 456 789`) and its IP.
5. On the helper PC: double-click `start_helper.bat`.
   - Type the client's IP and press **CONNECT + REQUEST VIEW**, or
     press **Scan LAN** and pick a discovered device.
6. The client presses ACCEPT on the popup. You now see their screen.

Both PCs must be on the same LAN / subnet (office or home network).

## Network ports

| Port | Protocol | Used for                       |
|------|----------|--------------------------------|
| 5555 | TCP      | Screen stream + control        |
| 5556 | UDP      | LAN discovery ("Scan LAN")     |

If 5555 is taken, the client walks up to 5566 automatically; Scan LAN
still finds it, manual-IP connects default to 5555 first.

## Audit log contents

Each line is one event, e.g.:

```
[2026-10-05 14:22:31] [CLIENT] INCOMING_REQUEST helper=IT-Bob ip=192.168.1.7 session_id=123456789 requested=view
[2026-10-05 14:22:36] [CLIENT] REQUEST_GRANTED helper=IT-Bob ip=192.168.1.7
[2026-10-05 14:25:02] [CLIENT] SESSION_ENDED_BY_CLIENT
```

Logs are plain text, timestamped, and kept per day. This is your
defensive evidence trail: you can always answer "who viewed this PC,
when, and for how long".

## Troubleshooting

- **Scan LAN finds nothing** -> both PCs on the same subnet? UDP 5556
  blocked by a guest/enterprise WiFi? Just connect by IP instead.
- **Connect fails** -> Windows Firewall on the client: allow inbound
  TCP 5555 for Python on private networks.
- **"GUI libraries are missing"** -> run `install_deps.bat`.
- **Popup never appeared** -> the request auto-expires after 30 s and
  the helper is told the client denied/timed out; retry.
- **Slow stream** -> lower the fps/quality constants at the top of
  `client.py` (StreamWorker defaults: 12 fps, JPEG quality 60).

## Optional: build standalone .exe files

With PyInstaller (`python -m pip install pyinstaller`), run in this
folder:

```
pyinstaller --onefile --noconsole --name SafeDesk-Client client.py common.py
pyinstaller --onefile --noconsole --name SafeDesk-Helper helper.py common.py
```

The exe files appear in `dist/`. Same ports, same logs, same consent
popup.
