"""
SafeDesk Remote Assist - CLIENT app (runs on the PC that gets viewed).

SAFETY MODEL
    * The client listens passively. It never initiates anything.
    * Every incoming request triggers a modal popup on the client screen
      showing WHO (name + IP) wants to view, and a fresh session ID.
    * The request is AUTO-REJECTED after 30 seconds of silence.
    * Only a human pressing "Accept" starts the screen stream.
    * Pressing "End session" (or closing the app) kills the stream instantly.
    * Everything is audit-logged to logs/client_YYYYMMDD.log.
"""

import io
import json
import os
import socket
import threading
import time

import common as C

try:
    import customtkinter as ctk
    GUI_OK = True
except Exception:                       # headless / missing tk
    GUI_OK = False


ACCENT_RED = "#E23B3B"
ACCENT_GREEN = "#2FA84F"
BG_DARK = "#16161A"
BG_PANEL = "#1E1E24"
TXT_DIM = "#9A9AA5"


# ---------------------------------------------------------------------------
# Screen streamer
# ---------------------------------------------------------------------------

class StreamWorker(threading.Thread):
    """Captures this PC's screen and pushes JPEG frames to the helper."""

    def __init__(self, sock, stop_event, logger, fps=12.0, quality=60, max_width=1600):
        super().__init__(daemon=True, name="screen-streamer")
        self.sock = sock
        self.stop_event = stop_event
        self.log = logger
        self.fps = fps
        self.quality = quality
        self.max_width = max_width
        self.frames_sent = 0
        self.error = None

    def run(self):
        try:
            import mss
            from PIL import Image
        except ImportError as exc:
            self.error = "missing dependency: %s" % exc
            self.log.log("STREAM_ERROR", detail=self.error)
            return

        resample = getattr(Image, "Resampling", Image).BILINEAR
        interval = 1.0 / self.fps
        try:
            with mss.mss() as sct:
                monitor = sct.monitors[1] if len(sct.monitors) > 1 else sct.monitors[0]
                self.log.log("STREAM_CAPTURE_START",
                             size="%dx%d" % (monitor["width"], monitor["height"]),
                             fps=self.fps, quality=self.quality)
                while not self.stop_event.is_set():
                    t0 = time.time()
                    raw = sct.grab(monitor)
                    img = Image.frombytes("RGB", raw.size, raw.bgra, "raw", "BGRX")
                    if img.width > self.max_width:
                        h = max(1, int(img.height * self.max_width / img.width))
                        img = img.resize((self.max_width, h), resample)
                    buf = io.BytesIO()
                    img.save(buf, "JPEG", quality=self.quality)
                    C.send_msg(self.sock, C.TYPE_FRAME, buf.getvalue())
                    self.frames_sent += 1
                    delay = interval - (time.time() - t0)
                    if delay > 0:
                        self.stop_event.wait(delay)
        except (OSError, RuntimeError) as exc:
            self.error = str(exc)
            self.log.log("STREAM_ERROR", detail=self.error[:200])
        finally:
            self.log.log("STREAM_FRAMES_SENT", count=self.frames_sent)


# ---------------------------------------------------------------------------
# Consent-gated TCP service
# ---------------------------------------------------------------------------

class ConsentService:
    """Accepts helper connections. EVERY session requires consent_cb to
    return a grant from the local user. No grant -> no data leaves the PC.
    """

    def __init__(self, consent_cb, logger, port=C.DEFAULT_TCP_PORT):
        self.consent_cb = consent_cb      # cb(request:dict, peer_ip:str) -> dict
        self.log = logger
        self.port = port
        self.active = False               # one session at a time
        self.stop_stream = threading.Event()
        self._worker = None
        self._conn = None
        self.session_info = None          # dict while a session is live
        self._sock = None
        self._bind()

    def _bind(self):
        last_err = None
        for offset in range(C.PORT_RANGE):
            port = C.DEFAULT_TCP_PORT + offset
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(("", port))
                s.listen(4)
                self._sock = s
                self.port = port
                self.log.log("LISTENING", port=port)
                return
            except OSError as exc:
                last_err = exc
                s.close()
        raise OSError("could not bind any port 5555-5566: %s" % last_err)

    def serve_forever(self):
        while True:
            try:
                conn, addr = self._sock.accept()
            except OSError:
                return
            if self.active:
                try:
                    C.send_json(conn, {"type": "denied", "reason": "busy"})
                except OSError:
                    pass
                conn.close()
                self.log.log("REQUEST_REJECTED_BUSY", ip=addr[0])
                continue
            threading.Thread(target=self._handle, args=(conn, addr),
                             daemon=True, name="session-handler").start()

    # -- one incoming helper connection ------------------------------------

    def _handle(self, conn, addr):
        conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        self.active = True
        self.stop_stream.clear()
        self.session_info = None
        started = time.time()
        helper = "?"
        granted = False
        try:
            conn.settimeout(C.CONSENT_TIMEOUT + 15)
            req = C.recv_json(conn)
            if not isinstance(req, dict) or req.get("type") != "connect_request":
                C.send_json(conn, {"type": "denied", "reason": "bad_request"})
                self.log.log("REQUEST_MALFORMED", ip=addr[0])
                return
            if req.get("proto") != C.PROTO_VERSION:
                C.send_json(conn, {"type": "denied", "reason": "protocol_mismatch"})
                self.log.log("REQUEST_PROTOCOL_MISMATCH",
                             ip=addr[0], proto=req.get("proto"))
                return

            helper = str(req.get("helper_name", "?"))[:40]
            self.log.log("INCOMING_REQUEST",
                         helper=helper, ip=addr[0],
                         session_id=req.get("session_id"),
                         requested=req.get("requested", "view"))

            # ---- THE GATE: block until the human decides (max 30 s) ----
            decision = self.consent_cb(req, addr[0]) or {}
            granted = bool(decision.get("granted"))
            C.send_json(conn, decision)
            if not granted:
                self.log.log("REQUEST_DENIED",
                             helper=helper, ip=addr[0],
                             reason=decision.get("reason", "unknown"))
                return

            self.log.log("REQUEST_GRANTED", helper=helper, ip=addr[0])
            self.session_info = {"helper": helper, "ip": addr[0],
                                 "started": started}
            self._conn = conn

            # ---- stream phase ----
            self._worker = StreamWorker(conn, self.stop_stream, self.log)
            self._worker.start()
            self.log.log("STREAM_START", helper=helper)

            conn.settimeout(None)
            while True:
                msg = C.recv_msg(conn)
                if msg is None:
                    self.log.log("HELPER_DISCONNECTED", helper=helper)
                    break
                mtype, payload = msg
                if mtype == C.TYPE_JSON:
                    obj = json.loads(payload.decode("utf-8"))
                    if obj.get("type") == "end":
                        self.log.log("SESSION_ENDED_BY_HELPER", helper=helper)
                        break
                    # any other control JSON is ignored on this side
        except (OSError, ValueError) as exc:
            if granted:
                self.log.log("CONNECTION_ERROR", detail=str(exc)[:200])
        finally:
            self.stop_stream.set()
            if self._worker:
                self._worker.join(timeout=3)
            try:
                conn.close()
            except OSError:
                pass
            self.active = False
            self.session_info = None
            self._conn = None
            self.log.log("SESSION_END",
                         helper=helper,
                         duration_sec=round(time.time() - started, 1))

    # -- user pressed "End session" in the client GUI -----------------------

    def end_session(self):
        self.log.log("SESSION_ENDED_BY_CLIENT")
        self.stop_stream.set()
        if self._conn:
            try:
                self._conn.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass


# ---------------------------------------------------------------------------
# Consent popup (modal, topmost, 30 s countdown)
# ---------------------------------------------------------------------------

if GUI_OK:

    class ConsentPopup(ctk.CTkToplevel):
        """The approval dialog. Nothing streams until Accept is pressed."""

        def __init__(self, master, req, peer_ip, on_done):
            super().__init__(master)
            self.configure(fg_color=BG_PANEL)
            self.title("SafeDesk - Connection Request")
            self.geometry("460x430")
            self.resizable(False, False)
            self.attributes("-topmost", True)
            self.on_done = on_done
            self.remaining = C.CONSENT_TIMEOUT
            self._answered = False

            sid = C.format_id(req.get("session_id", "000000000"))
            name = str(req.get("helper_name", "Unknown"))[:40]

            head = ctk.CTkFrame(self, fg_color=BG_DARK, corner_radius=0)
            head.pack(fill="x")
            ctk.CTkLabel(head, text="CONNECTION REQUEST",
                         font=("Segoe UI", 15, "bold"),
                         text_color=ACCENT_RED).pack(pady=(14, 2))
            ctk.CTkLabel(head, text="Someone wants to VIEW this screen",
                         font=("Segoe UI", 12),
                         text_color=TXT_DIM).pack(pady=(0, 12))

            body = ctk.CTkFrame(self, fg_color="transparent")
            body.pack(fill="both", expand=True, padx=24, pady=10)

            ctk.CTkLabel(body, text="Helper", font=("Segoe UI", 11),
                         text_color=TXT_DIM).pack()
            ctk.CTkLabel(body, text=name,
                         font=("Segoe UI", 17, "bold")).pack(pady=(0, 6))

            ctk.CTkLabel(body, text="From IP", font=("Segoe UI", 11),
                         text_color=TXT_DIM).pack()
            ctk.CTkLabel(body, text=peer_ip,
                         font=("Consolas", 15, "bold")).pack(pady=(0, 6))

            ctk.CTkLabel(body, text="Session ID - quote this when verifying",
                         font=("Segoe UI", 11),
                         text_color=TXT_DIM).pack()
            ctk.CTkLabel(body, text=sid, font=("Consolas", 22, "bold"),
                         text_color="#F5C542").pack(pady=(2, 10))

            self.countdown_lbl = ctk.CTkLabel(
                body, text="Auto-REJECT in %d s if you do nothing" % self.remaining,
                font=("Segoe UI", 11), text_color=TXT_DIM)
            self.countdown_lbl.pack(pady=(0, 8))

            btns = ctk.CTkFrame(body, fg_color="transparent")
            btns.pack(pady=(2, 4))
            ctk.CTkButton(btns, text="ACCEPT", width=150, height=44,
                          fg_color=ACCENT_GREEN, hover_color="#25853D",
                          font=("Segoe UI", 14, "bold"),
                          command=lambda: self._answer(True, "user")).pack(
                              side="left", padx=8)
            ctk.CTkButton(btns, text="REJECT", width=150, height=44,
                          fg_color=ACCENT_RED, hover_color="#B22D2D",
                          font=("Segoe UI", 14, "bold"),
                          command=lambda: self._answer(False, "user")).pack(
                              side="left", padx=8)

            self.protocol("WM_DELETE_WINDOW",
                          lambda: self._answer(False, "popup_closed"))
            self._countdown()
            self.after(200, self._raise)

        def _raise(self):
            try:
                self.lift()
                self.focus_force()
                self.grab_set()
            except Exception:
                pass

        def _countdown(self):
            if self._answered:
                return
            if self.remaining <= 0:
                self._answer(False, "timeout")
                return
            self.countdown_lbl.configure(
                text="Auto-REJECT in %d s if you do nothing" % self.remaining)
            self.remaining -= 1
            self.after(1000, self._countdown)

        def _answer(self, granted, reason):
            if self._answered:
                return
            self._answered = True
            try:
                self.grab_release()
            except Exception:
                pass
            self.destroy()
            self.on_done({"granted": granted, "mode": "view",
                          "reason": reason if not granted else "user"})


# ---------------------------------------------------------------------------
# Client GUI
# ---------------------------------------------------------------------------

if GUI_OK:

    class ClientApp(ctk.CTk):
        def __init__(self):
            super().__init__()
            ctk.set_appearance_mode("dark")
            self.title("SafeDesk Remote Assist - Client")
            self.geometry("470x640")
            self.resizable(False, False)
            self.configure(fg_color=BG_DARK)

            self.device_id = C.make_device_id("client")
            self.log = C.AuditLogger("client", gui_cb=self._gui_log)
            self.service = None
            self._end_btn = None

            # ---- header ----
            head = ctk.CTkFrame(self, fg_color=BG_PANEL, corner_radius=0)
            head.pack(fill="x")
            ctk.CTkLabel(head, text="SafeDesk Remote Assist",
                         font=("Segoe UI", 19, "bold")).pack(pady=(14, 0))
            self.status_lbl = ctk.CTkLabel(head, text="PROTECTED - waiting for requests",
                                           font=("Segoe UI", 12, "bold"),
                                           text_color=ACCENT_GREEN)
            self.status_lbl.pack(pady=(2, 14))

            # ---- this device card ----
            card = ctk.CTkFrame(self, fg_color=BG_PANEL, corner_radius=10)
            card.pack(fill="x", padx=16, pady=(14, 8))
            ctk.CTkLabel(card, text="THIS DEVICE", font=("Segoe UI", 11),
                         text_color=TXT_DIM).pack(pady=(12, 4))
            ctk.CTkLabel(card, text=C.format_id(self.device_id),
                         font=("Consolas", 26, "bold")).pack()
            ctk.CTkButton(card, text="Copy my ID", width=110, height=26,
                          fg_color="#3A3A44", hover_color="#4A4A55",
                          font=("Segoe UI", 11),
                          command=self._copy_id).pack(pady=(4, 2))
            self.addr_lbl = ctk.CTkLabel(
                card, text="%s  -  %s" % (C.host_name(), C.get_lan_ip()),
                font=("Segoe UI", 12), text_color=TXT_DIM)
            self.addr_lbl.pack(pady=(0, 12))

            # ---- sharing banner (hidden until live) ----
            self.share_frame = ctk.CTkFrame(self, fg_color="#5A1E1E",
                                            corner_radius=10)
            # packed only while a session is live
            self.share_lbl = ctk.CTkLabel(self.share_frame,
                                          text="", font=("Segoe UI", 12, "bold"),
                                          text_color="#FFD7D7")
            self.share_lbl.pack(side="left", padx=14, pady=10)
            self._end_btn = ctk.CTkButton(self.share_frame, text="END SESSION",
                                          width=120, height=30,
                                          fg_color=ACCENT_RED,
                                          hover_color="#B22D2D",
                                          font=("Segoe UI", 11, "bold"),
                                          command=self._end_clicked)
            self._end_btn.pack(side="right", padx=14, pady=8)

            # ---- event log ----
            ctk.CTkLabel(self, text="SECURITY LOG (also saved to logs/)",
                         font=("Segoe UI", 11), text_color=TXT_DIM
                         ).pack(anchor="w", padx=20, pady=(10, 2))
            self.logbox = ctk.CTkTextbox(self, fg_color=BG_PANEL,
                                         text_color="#C9C9D1",
                                         font=("Consolas", 11), height=250)
            self.logbox.pack(fill="both", expand=True, padx=16, pady=(0, 8))
            self.logbox.configure(state="disabled")

            ctk.CTkLabel(
                self, wraplength=430, justify="left",
                text="Nothing is shared until you press ACCEPT on a request. "
                     "Every decision is recorded in the audit log.",
                font=("Segoe UI", 11), text_color=TXT_DIM).pack(pady=(0, 12))

            self._start_services()
            self.protocol("WM_DELETE_WINDOW", self._on_close)

        # -- services -------------------------------------------------------

        def _start_services(self):
            self.service = ConsentService(self._consent_flow, self.log)
            C.start_discovery_responder(
                lambda: {"id": self.device_id, "name": C.host_name(),
                         "port": self.service.port},
                logger=self.log)
            self.log.log("CLIENT_READY", id=self.device_id,
                         ip=C.get_lan_ip(), port=self.service.port)
            threading.Thread(target=self.service.serve_forever,
                             daemon=True, name="tcp-listener").start()

        # -- consent wiring (runs on the session-handler thread) ------------

        def _consent_flow(self, req, peer_ip):
            result = {}
            done = threading.Event()

            def ui():
                if not GUI_OK:
                    result.update({"granted": False, "reason": "no_gui"})
                    done.set()
                    return
                self._show_popup(req, peer_ip, result, done)

            self.after(0, ui)
            done.wait(C.CONSENT_TIMEOUT + 10)
            return result

        def _show_popup(self, req, peer_ip, result, done):
            def on_done(decision):
                result.update(decision)
                done.set()

            popup = ConsentPopup(self, req, peer_ip, on_done)
            self._set_status("REQUEST - %s (%s)" % (
                str(req.get("helper_name", "?"))[:24], peer_ip), "#F5C542")
            # When the popup resolves, restore status line.
            def watcher():
                if done.is_set():
                    if result.get("granted"):
                        self._set_status("SHARING SCREEN", ACCENT_RED)
                        self.share_lbl.configure(
                            text="LIVE - %s (%s) is viewing this screen" % (
                                str(req.get("helper_name", "?"))[:24], peer_ip))
                        self.share_frame.pack(fill="x", padx=16, pady=8)
                        self._poll_session_end()
                    else:
                        self._set_status("PROTECTED - waiting for requests",
                                         ACCENT_GREEN)
                else:
                    self.after(400, watcher)
            self.after(400, watcher)

        def _poll_session_end(self):
            """Flip the banner back when the session ends."""
            if self.service and not self.service.active:
                self.share_frame.pack_forget()
                self._set_status("PROTECTED - waiting for requests", ACCENT_GREEN)
                return
            self.after(700, self._poll_session_end)

        # -- small GUI helpers ----------------------------------------------

        def _set_status(self, text, color):
            self.status_lbl.configure(text=text, text_color=color)

        def _gui_log(self, line):
            def append():
                try:
                    self.logbox.configure(state="normal")
                    self.logbox.insert("end", line + "\n")
                    self.logbox.see("end")
                    self.logbox.configure(state="disabled")
                except Exception:
                    pass
            try:
                self.after(0, append)
            except RuntimeError:
                pass

        def _copy_id(self):
            try:
                self.clipboard_clear()
                self.clipboard_append(self.device_id)
                self._set_status("ID copied to clipboard", "#7FB2FF")
            except Exception:
                pass

        def _end_clicked(self):
            if self.service:
                self.service.end_session()

        def _on_close(self):
            if self.service and self.service.active:
                self.log.log("CLIENT_QUIT_DURING_SESSION")
                self.service.end_session()
            self.destroy()


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------

def main():
    if not GUI_OK:
        print("[SafeDesk] GUI libraries are missing.")
        print("[SafeDesk] Run install_deps.bat, or:")
        print("           python -m pip install customtkinter")
        return 1
    app = ClientApp()
    print("[SafeDesk] Client running. Your ID: %s   IP: %s" % (
        C.format_id(app.device_id), C.get_lan_ip()))
    print("[SafeDesk] No screen sharing starts until you press ACCEPT.")
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
